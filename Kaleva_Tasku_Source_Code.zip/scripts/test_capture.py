import os
import threading
import http.server
import socketserver
import time
from playwright.sync_api import sync_playwright

class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory='dist', **kwargs)
    def log_message(self, format, *args):
        pass

def main():
    server = socketserver.TCPServer(('127.0.0.1', 8999), QuietHandler)
    server_thread = threading.Thread(target=server.serve_forever)
    server_thread.daemon = True
    server_thread.start()
    print("Local server started on port 8999")

    chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(executable_path=chrome_path)
            page = browser.new_page(viewport={'width': 1280, 'height': 850})
            page.goto('http://127.0.0.1:8999')
            page.wait_for_timeout(1500)
            os.makedirs('screenshots', exist_ok=True)
            page.screenshot(path='screenshots/app_main.png')
            print("Saved screenshots/app_main.png")

            # Click next pill to see another story
            buttons = page.query_selector_all('button')
            print(f"Found {len(buttons)} buttons")
            browser.close()
    finally:
        server.shutdown()
        print("Server stopped.")

if __name__ == '__main__':
    main()
