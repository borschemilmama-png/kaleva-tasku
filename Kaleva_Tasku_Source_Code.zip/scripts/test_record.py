import os
import time
from playwright.sync_api import sync_playwright

def test_video():
    chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
    os.makedirs("test_video_out", exist_ok=True)
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=chrome_path)
        context = browser.new_context(
            record_video_dir="test_video_out",
            record_video_size={"width": 1920, "height": 1080},
            viewport={"width": 1920, "height": 1080}
        )
        page = context.new_page()
        page.set_content("""
        <body style="background:#002855;color:white;display:flex;align-items:center;justify-content:center;height:100vh;font-family:sans-serif;">
            <h1>Testing Video Recording</h1>
        </body>
        """)
        time.sleep(2)
        page.close()
        context.close()
        browser.close()
        print("Video recorded successfully!")

if __name__ == '__main__':
    test_video()
