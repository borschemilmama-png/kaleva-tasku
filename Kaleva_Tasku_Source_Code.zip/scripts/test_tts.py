import asyncio
import edge_tts

async def test():
    comm = edge_tts.Communicate("Kaleva Tasku: An agentic, visual-first civic newsroom for multilingual communities.", "en-US-ChristopherNeural")
    await comm.save("test_speech.mp3")
    print("TTS Success!")

if __name__ == '__main__':
    asyncio.run(test())
