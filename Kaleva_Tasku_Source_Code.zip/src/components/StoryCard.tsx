import React from 'react';
import { StorySlide, Language } from '../types';
import { DigitalSituationDiagram } from './DigitalSituationDiagram';
import { ShieldCheck, MapPin, ArrowUpRight } from 'lucide-react';

interface StoryCardProps {
  story: StorySlide;
  language: Language;
  onOpenBroadsheet: (story: StorySlide) => void;
}

export const StoryCard: React.FC<StoryCardProps> = ({
  story,
  language,
  onOpenBroadsheet,
}) => {
  return (
    <div className="w-full h-full flex flex-col bg-white text-slate-900 rounded-[32px] border-2 border-slate-200 shadow-xl overflow-hidden relative select-none">
      {/* Main Card Viewport */}
      <div className="flex-1 flex flex-col p-4 sm:p-5 overflow-hidden">
        {/* СТРОЧКА С КАТЕГОРИЕЙ, АДРЕСОМ И ПРОЦЕНТОМ ДОВЕРИЯ: Сдвинута максимально вниз впритык к названию-ссылке */}
        <div className="flex items-center justify-between text-xs shrink-0 mb-1">
          <div className="flex items-center gap-2 min-w-0">
            <span className="px-2 py-0.5 rounded-md bg-[#cf2e2e] text-white text-[10px] font-black uppercase tracking-wider shrink-0 shadow-xs">
              {story.categoryLabel[language]}
            </span>
            <span className="flex items-center gap-1 text-[11px] text-slate-600 font-semibold truncate">
              <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              <span className="truncate">{story.district}</span>
            </span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <span className="flex items-center gap-1 text-[10px] font-mono text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200 font-bold">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              {story.credibilityScore}% {story.jsnStatus.split(' ')[0]}
            </span>
          </div>
        </div>

        {/* 1. НАЗВАНИЕ-ССЫЛКА (Почти впритык к информационной строчке сверху) */}
        <div className="shrink-0">
          <button
            type="button"
            onClick={() => onOpenBroadsheet(story)}
            className="text-left w-full group cursor-pointer block"
            title="Klikkaa avataksesi koko toimituksen juttu"
          >
            <h2 className="text-xl sm:text-2xl font-extrabold text-[#002855] group-hover:text-[#cf2e2e] transition-colors leading-tight tracking-tight flex items-start gap-2 font-sans">
              <span className="flex-1">{story.headline[language]}</span>
              <ArrowUpRight className="w-6 h-6 text-slate-400 group-hover:text-[#cf2e2e] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all shrink-0 mt-0.5" />
            </h2>
          </button>
        </div>

        {/* 2 & 3. РАЗДЕЛ С ПРОИСШЕСТВИЕМ (ТЕКСТ НАД КАРТИНКОЙ) + САЛАТОВАЯ СТРЕЛКА ПО ЦЕНТРУ + РАЗДЕЛ С РЕШЕНИЕМ (ТЕКСТ НАД КАРТИНКОЙ) */}
        <div className="mt-4 sm:mt-5 flex-1 flex flex-col justify-between pb-2 sm:pb-3">
          <DigitalSituationDiagram diagram={story.diagram} language={language} />
        </div>
      </div>
    </div>
  );
};
