import React from 'react';
import { DigitalDiagram, Language } from '../types';

interface DigitalSituationDiagramProps {
  diagram: DigitalDiagram;
  language: Language;
}

export const DigitalSituationDiagram: React.FC<DigitalSituationDiagramProps> = ({
  diagram,
  language
}) => {
  return (
    <div className="w-full flex-1 flex flex-col justify-between">
      {/* 1. Problem / Situation: ALL TEXT ABOVE THE PICTURE */}
      <div className="w-full shrink-0 space-y-2">
        <div className="flex items-center">
          <span className="text-[11px] font-mono font-bold uppercase tracking-wider flex items-center gap-2 text-slate-700">
            <span className="w-2 h-2 rounded-full bg-[#ff5500] shrink-0 inline-block" />
            <span>TILANNE</span>
          </span>
        </div>
        
        {/* All Text (Title & Detail) above picture */}
        <div className="space-y-1">
          <h3 className="text-base sm:text-lg font-black text-slate-950 leading-snug tracking-tight font-sans">
            {diagram.problem.title[language]}
          </h3>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-medium">
            {diagram.problem.detail[language]}
          </p>
        </div>

        {/* Picture / Icon UNDER the text */}
        <div className="text-3xl sm:text-4xl pt-0.5 select-none">
          {diagram.problem.icon}
        </div>
      </div>

      {/* 2. Arrow: SHORTER & VIBRANT SALAD GREEN (#22c55e), EXACTLY MIDWAY */}
      <div className="flex-1 flex items-center justify-center my-auto py-1.5">
        <svg 
          className="w-7 h-7 sm:w-8 sm:h-8 text-[#22c55e] select-none" 
          viewBox="0 0 24 24" 
          fill="none" 
          stroke="currentColor" 
          strokeWidth="4.5" 
          strokeLinecap="round" 
          strokeLinejoin="round"
        >
          <line x1="12" y1="5" x2="12" y2="19" />
          <polyline points="16 14 12 19 8 14" />
        </svg>
      </div>

      {/* 3. Solution / Action: If resolved, ONLY phrase "Tilanne on ratkaistu, lisätoimenpiteitä ei vaadita." */}
      <div className="w-full shrink-0 space-y-2">
        <div className="flex items-center">
          <span className="text-[11px] font-mono font-bold uppercase tracking-wider flex items-center gap-2 text-slate-700">
            <span className="w-2 h-2 rounded-full bg-[#ff5500] shrink-0 inline-block" />
            <span>TOIMINTAOHJE</span>
          </span>
        </div>

        {diagram.isResolved ? (
          <div className="space-y-2 pt-0.5">
            <p className="text-base sm:text-lg font-bold text-slate-900 leading-snug tracking-tight font-sans">
              Tilanne on ratkaistu, lisätoimenpiteitä ei vaadita.
            </p>
            <div className="text-3xl sm:text-4xl pt-0.5 select-none">
              ✅
            </div>
          </div>
        ) : (
          <>
            <div className="space-y-1">
              <h3 className="text-base sm:text-lg font-black text-slate-950 leading-snug tracking-tight font-sans">
                {diagram.solution.title[language]}
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-medium">
                {diagram.solution.detail[language]}
              </p>
            </div>
            <div className="text-3xl sm:text-4xl pt-0.5 select-none">
              {diagram.solution.icon}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
