import React from 'react';
import { Volume2, VolumeX, CloudSnow, Sparkles, Radio } from 'lucide-react';

interface HeaderMastheadProps {
  isPlayingAudio: boolean;
  onToggleAudio: () => void;
}

export const HeaderMasthead: React.FC<HeaderMastheadProps> = ({
  isPlayingAudio,
  onToggleAudio
}) => {
  return (
    <header className="w-full bg-white border-b-2 border-[#dedad2] shadow-xs sticky top-0 z-40">
      {/* Topmost Micro Bar (Weather & Dateline) */}
      <div className="bg-[#f0ece4] px-4 py-1.5 border-b border-[#e2ded4] flex items-center justify-between text-[11px] font-sans text-[#5c5852]">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 font-bold text-[#002855]">
            <CloudSnow className="w-3.5 h-3.5 text-[#002855]" />
            Oulu −24°C • Pääkallokeli
          </span>
          <span className="hidden sm:inline text-slate-400">•</span>
          <span className="hidden sm:inline font-medium">Lauantai 24.10.2026</span>
          <span className="hidden md:inline text-slate-400">•</span>
          <span className="hidden md:inline text-[#1a7a40] font-semibold">✓ Baana aurattu 06:30</span>
        </div>

        <div className="flex items-center gap-2 font-mono text-[10px] text-slate-500">
          <span className="flex items-center gap-1 text-[#cf2e2e] font-bold">
            <Radio className="w-3 h-3 animate-pulse" />
            LIVE OULU
          </span>
          <span>•</span>
          <span className="font-bold text-[#002855]">JSN § 10 Valvottu</span>
        </div>
      </div>

      {/* Main Brand Row (Exact kaleva.fi style: Black Serif Wordmark) */}
      <div className="max-w-4xl mx-auto px-4 py-2.5 flex items-center justify-between gap-4">
        {/* Kaleva Logo Wordmark */}
        <div className="flex items-center gap-3">
          <a href="https://www.kaleva.fi" target="_blank" rel="noreferrer" className="flex items-baseline gap-2 group">
            <span className="text-3xl sm:text-4xl font-serif font-black tracking-tight text-[#000000] uppercase hover:text-[#cf2e2e] transition-colors">
              Kaleva
            </span>
            <span className="text-[10px] font-mono font-black uppercase tracking-wider px-2 py-0.5 rounded bg-[#cf2e2e] text-white">
              Tasku
            </span>
          </a>
          <span className="hidden sm:inline-block text-[11px] text-[#5c5852] font-serif italic border-l border-slate-300 pl-3">
            Oululaisten arjen tulkki ja suora uutisvirta
          </span>
        </div>

        {/* Right Section: Hands-free Audio Player */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onToggleAudio}
            className={`px-3.5 py-1.5 rounded-full border text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-xs ${
              isPlayingAudio
                ? 'bg-[#1a7a40] text-white border-[#1a7a40] animate-pulse'
                : 'bg-[#f0ece4] hover:bg-[#e6e1d6] text-[#002855] border-[#dedad2]'
            }`}
            title="Kuuntele uutinen ääneen suomeksi (Korva AI)"
          >
            {isPlayingAudio ? (
              <>
                <VolumeX className="w-3.5 h-3.5" />
                <span>Pysäytä ääni</span>
              </>
            ) : (
              <>
                <Volume2 className="w-3.5 h-3.5 text-[#002855]" />
                <span>Kuuntele (30s)</span>
              </>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
